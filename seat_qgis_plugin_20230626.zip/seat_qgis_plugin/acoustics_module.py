def init_wfs():
    # No params, initializes the weighting function xarrays
    # Output is dictionary of xarrays corresponding of weighting functions, in dB, f is in Hz
    freq_np = np.arange(0.01, 1000, 0.01) # in kHz

    # Low frequency weighting function
    # citation: NMFS 2018
    a = 1
    b = 2
    f1 = 0.2
    f2 = 19
    C = 0.13
    W_LF = C+ 10*np.log10(((freq_np/f1)**(2*a))/(((1+(freq_np/f1)**2)**a)*((1+(freq_np/f2)**2)**b)))
    W_LF = xr.DataArray(W_LF, coords={'f': freq_np*1000}) # in Hz

    # Mid frequency weighting function
    # citation: NMFS 2018
    a = 1.6
    b = 2
    f1 = 8.8
    f2 = 110
    C = 1.20
    W_MF = C+ 10*np.log10(((freq_np/f1)**(2*a))/(((1+(freq_np/f1)**2)**a)*((1+(freq_np/f2)**2)**b)))
    W_MF = xr.DataArray(W_MF, coords={'f': freq_np*1000})   # in Hz

    # High frequency weighting function
    # citation: NMFS 2018       
    a = 1.8
    b = 2
    f1 = 12
    f2 = 140
    C = 1.36
    W_HF = C+ 10*np.log10(((freq_np/f1)**(2*a))/(((1+(freq_np/f1)**2)**a)*((1+(freq_np/f2)**2)**b)))
    W_HF = xr.DataArray(W_HF, coords={'f': freq_np*1000})  # in Hz

    # Phocid pinnipeds weighting function
    # citation: NMFS 2018
    a = 1
    b = 2
    f1 = 1.9
    f2 = 30
    C = 0.75
    W_PW = C+ 10*np.log10(((freq_np/f1)**(2*a))/(((1+(freq_np/f1)**2)**a)*((1+(freq_np/f2)**2)**b)))
    W_PW = xr.DataArray(W_PW, coords={'f': freq_np*1000})  # in Hz

    # Otariid pinnipeds weighting function
    # citation: NMFS 2018
    a = 2
    b = 2
    f1 = 0.94
    f2 = 25
    C = 0.64
    W_OW = C+ 10*np.log10(((freq_np/f1)**(2*a))/(((1+(freq_np/f1)**2)**a)*((1+(freq_np/f2)**2)**b)))
    W_OW = xr.DataArray(W_OW, coords={'f': freq_np*1000})  # in Hz

    weighting_functions = {"LFC":W_LF, "MFC":W_MF, "HFC":W_HF, "PPW":W_PW, "OPW":W_OW}
    return(weighting_functions)

import numpy as np
from scipy.signal import hilbert, stft
import xarray as xr

# ==========================================================================
# Peak sound pressure level (SPL_pk)
# ==========================================================================


def SPL_pk_dB(y):
    # Equaltion 2 from Wilfod et al 2021
    # Assumes the value is in same units as reference value [uPa for pressure, nm/s for velocity]
    # y = originally sampled time series
    # Output is in dB re 1 uPa for pressure or re 1 nm/s for velocity
    if len(y) > 0:
        SPL_pk = 10 * np.log10(np.max(y**2))
        return float(SPL_pk)
    else:
        return np.nan


# ==========================================================================
# Root mean square Sound Pressure Level (SPL_rms)
# ==========================================================================


def SPL_rms_dB(y, dt):
    # Equaltion 1 from Wilfod et al 2021
    # Assumes the value of y is in same units as reference value [uPa for pressure, nm/s for velocity]
    # y = originally sampled time series
    # dt = time step of originally sampled time series (in s)
    # Output is in dB re 1 uPa or re 1 nm/s
    if len(y) > 0:
        T = len(y) * dt
        rms_SPL_dB = 20 * np.log10(np.sqrt((1 / T) * np.trapz(y**2, dx=dt)))
        return rms_SPL_dB
    else:
        return np.nan


# ==========================================================================
# Sound Exposure Level (SEL)
# ==========================================================================


def SEL_dB(y, dt):
    # Assumes the value of y is in same units as reference value [uPa for pressure, nm/s for velocity]
    # y = originally sampled time series
    # dt = time step of originally sampled time series (in s)
    # Output is in dB re 1 uPa * s  or dB re 1 nm/s * s
    if len(y) > 0:
        SEL = 10 * np.log10(np.trapz(y**2, dx=dt))
        return SEL
    else:
        return np.nan
    
# ==========================================================================
# Calculate all metrics from original frequency spectrum; transmission loss dictionary, and weighting functions
# ==========================================================================
def calc_all_metrics(f_og_db, w_fxn):
    """
    Parameters:
    f_og_db = frequency xarray of original frequency domain in dB; one dimension must be called f (frequency, in Hz).  1 Hz resolution, from 0-1023 Hz. 
    w_fxn = weighting function xarray by frequency; one dimension must be called f (frequency, in Hz), higher resolution and coverage than f_og_db is better   
    
    Outputs:
    returns dictionary of metrics of rmsSPL, peakSPL, SEL, both weighted and unweighted, all in dB
    """
    # Reshape appropriate weighting function to match same shape as f_og_db
    w_fxn_sub = w_fxn.sel(f=f_og_db['f'],  method = "nearest")

    # Calculate frequency resolution of transmission loss 
    # freqs = [int(x.replace("TL", "")) for x in list(TL_dict.keys())]
    # freqs.sort()
    # freq_resolution = freqs[1]- freqs[0]

    # # Produce modified spectra at point of interest (f_mod_dB) based on tranmission loss step function
    # f_mod_db = f_og_db.copy()
    # for key in TL_dict.keys():
    #     freq = int(key.replace("TL", ""))
    #     f1, f2 = int(freq-freq_resolution/2), int(freq+freq_resolution/2)
    #     TL = TL_dict[key] # in dB
    #     f_mod_db[f1:f2] = f_og_db[f1:f2]-TL
    
    # Apply weighting functions to modified spectra
    f_mod_db_w = xr.DataArray(w_fxn_sub.values + f_og_db.values, coords={'f': f_og_db['f']}) 

    # Turn f_mod and f_mod_w into uPa from dB
    f_mod_w = 10**(f_mod_db_w.real/20)
    f_mod = 10**(f_og_db.real/20)

    # inverse fft to switch into time domain for both the modified and weighted modified spectra
    # f_mod is array of uPa from 0-1023 Hz at 1 Hz intervals
    fs = 2048 # sampling frequency, in Hz
    # get time series of flat modified spectrum
    f_mod_double = np.concatenate((f_mod, np.flipud(f_mod)))
    t_mod = np.real(np.fft.ifft(f_mod_double))
    time_coords = np.arange(0,len(t_mod))/fs
    t_mod_xr = xr.DataArray(t_mod, coords={'time': time_coords}) 

    # get time series of weighted modified spectrum
    f_mod_double_w = np.concatenate((f_mod_w, np.flipud(f_mod_w)))
    t_mod_w = np.real(np.fft.ifft(f_mod_double_w))
    t_mod_xr_w = xr.DataArray(t_mod_w, coords={'time': time_coords}) 

    dt = 1/fs # time step, in s
    metrics = {}
    metrics['SPL_rms_flat'] = SPL_rms_dB(t_mod_xr, dt)
    metrics['SPL_rms_weighted'] = SPL_rms_dB(t_mod_xr_w, dt)
    metrics['SPL_pk_flat'] = SPL_pk_dB(t_mod_xr)
    metrics['SPL_pk_weighted'] = SPL_pk_dB(t_mod_xr_w)
    metrics['SEL_flat'] = SEL_dB(t_mod_xr, dt)
    metrics['SEL_weighted'] = SEL_dB(t_mod_xr_w, dt)

    return metrics